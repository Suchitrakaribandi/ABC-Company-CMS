import React, { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
  const [heading, setHeading] = useState('');
  const [newHeading, setNewHeading] = useState('');

  useEffect(() => {
    axios.get('/api/heading')
      .then(response => setHeading(response.data.heading))
      .catch(error => console.error('Error fetching heading:', error));
  }, []);

  const updateHeading = () => {
    axios.post('/api/heading', { heading: newHeading })
      .then(response => setHeading(newHeading))
      .catch(error => console.error('Error updating heading:', error));
  };

  return (
    <div className="p-4 min-h-screen bg-gray-100">
      <h1 className="text-4xl font-bold mb-4">{heading}</h1>
      <p>Hyper boost your Revenue Management, Marketing and Commercial Functions with Business Ready AI</p>
      <input
        type="text"
        value={newHeading}
        onChange={(e) => setNewHeading(e.target.value)}
        placeholder="Enter new heading"
        className="border rounded w-full p-2 mb-2"
      />
      <button onClick={updateHeading} className="w-full bg-blue-500 text-white py-2 rounded">Update Heading</button>
    </div>
  );
}

export default App;
