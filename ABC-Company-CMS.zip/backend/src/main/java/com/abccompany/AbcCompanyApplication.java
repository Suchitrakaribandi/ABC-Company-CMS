package com.abccompany;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AbcCompanyApplication {
    public static void main(String[] args) {
        SpringApplication.run(AbcCompanyApplication.class, args);
    }
}
